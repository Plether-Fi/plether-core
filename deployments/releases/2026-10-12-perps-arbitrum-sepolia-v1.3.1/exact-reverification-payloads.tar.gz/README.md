# v1.3.1 exact-match reverification inputs

All sources are already public. Arbiscan retains older similar-match constructor records for these two new addresses and responded "Already Verified" to both initial and repeated exact submissions. Runtime and full on-chain creation-input checks independently match the qualified build.

Use request.json for the new addresses, exact constructor arguments, qualified contract names, compiler version and last submission GUIDs. Each standard JSON input was independently fingerprinted against the qualified source export.

Etherscan documents a whitelist for similar-match reverification: https://info.etherscan.com/update-on-similar-match-contract-verification/
The documented process is to verify contract ownership with the explorer account, request reverification access from explorer support, and submit these unchanged standard JSON inputs and constructor arguments after access is enabled. No support message has been sent and no ownership message has been signed by this operation. No further blockchain transaction or redeployment is needed for source verification.
