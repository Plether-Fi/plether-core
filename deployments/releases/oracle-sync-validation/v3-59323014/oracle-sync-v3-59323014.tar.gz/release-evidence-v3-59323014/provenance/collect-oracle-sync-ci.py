#!/usr/bin/env python3
"""Read-only GitHub Actions evidence collector. Never publishes or declares a release qualified."""
import argparse
import base64
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
CI_JOBS = {
    'build', 'Package (shared)', 'Package (spot)', 'Package (options)', 'Package (perps-aa)',
    'Package (perps)', 'TypeScript (perps-aa-client)', 'Coverage (core protocol)',
    'Coverage (perps)', 'Coverage (options)', 'Slither (shared)', 'Slither (spot)',
    'Slither (options)', 'Slither (perps)', 'Slither (perps-aa)',
}
DEEP_JOBS = {f'Perps deep shard {i}/4' for i in range(1, 5)} | {'Perps deep (all shards)'}
INVARIANTS = [
    'invariant_EthConservedAcrossFeesRefundsAndClaims',
    'invariant_AllRequiredPathsRemainExercised',
    'invariant_ExecutionInstalledMarksAlwaysHaveStoredFeedCoverage',
]
SHA = re.compile(r'^[0-9a-f]{40}$')
REQUIRED_STEPS = {
    'build': ['Check formatting', 'Check package boundaries', 'Test oracle release evidence tooling',
              'Build', 'Run integration and script tests'],
    'Package (perps)': ['Build package', 'Enforce production deployment-size limits', 'Run fast package tests'],
    'TypeScript (perps-aa-client)': ['Install dependencies', 'Run tests', 'Type-check', 'Build',
                                    'Check immutable package release tooling', 'Pack and test installed package'],
    'Perps deep (all shards)': ['Require every perps package shard'],
}
for package in ('shared', 'spot', 'options', 'perps-aa'):
    REQUIRED_STEPS['Package (' + package + ')'] = ['Build package'] + (
        [] if package == 'shared' else ['Run package fuzz and invariant tests', 'Run package tests'])
for name in ('Coverage (core protocol)', 'Coverage (perps)', 'Coverage (options)'):
    REQUIRED_STEPS[name] = ['Run coverage', 'Filter coverage report', 'Preserve coverage evidence']
for package in ('shared', 'spot', 'options', 'perps', 'perps-aa'):
    REQUIRED_STEPS['Slither (' + package + ')'] = ['Run Slither', 'Preserve static-analysis evidence']
for shard in range(1, 5):
    REQUIRED_STEPS[f'Perps deep shard {shard}/4'] = ['Select fuzz seed', 'Build production package', 'Run package test shard']


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def checkout_commit(log):
    lines = log.splitlines()
    commits = []
    for i, line in enumerate(lines[:-1]):
        if re.search(r'git log -1 --format=%H(?:\s|$)', line):
            match = re.search(r'\b([0-9a-f]{40})\s*$', lines[i + 1])
            if match:
                commits.append(match[1])
    if len(commits) != 1:
        raise ValueError('Expected exactly one full checkout commit in the checkout log')
    return commits[0]


def select_latest_jobs(all_jobs, run_id, source_sha, latest_attempt):
    jobs = []
    for name in sorted({job['name'] for job in all_jobs}):
        history = [job for job in all_jobs if job['name'] == name]
        if any(type(job.get('run_attempt')) is not int or not 1 <= job['run_attempt'] <= latest_attempt
               or job.get('run_id') != run_id or job.get('head_sha') != source_sha for job in history):
            raise ValueError(f'Job attempt/run/source provenance differs: {name}')
        newest = max(job['run_attempt'] for job in history)
        selected = [job for job in history if job['run_attempt'] == newest]
        if len(selected) != 1:
            raise ValueError(f'Duplicate latest job execution: {name}')
        jobs.append(selected[0])
    return jobs


def execution_origin(job, all_jobs):
    # GitHub copies previously successful executions into a failed-job retry with a NEW
    # job ID/run_attempt but the original timestamps/steps/logs. Identify that original
    # execution; the caller additionally verifies byte-identical log content before use.
    identity = ('name', 'run_id', 'head_sha', 'started_at', 'completed_at', 'status', 'conclusion', 'steps')
    matches = [candidate for candidate in all_jobs
               if all(candidate.get(field) == job.get(field) for field in identity)]
    return min(matches, key=lambda candidate: (candidate['run_attempt'], candidate['id']))


def sarif_summary(data):
    report = json.loads(data)
    if report.get('version') != '2.1.0' or not report.get('runs'):
        raise ValueError('Invalid or missing SARIF run')
    levels, severities, rules = Counter(), Counter(), Counter()
    findings = []
    for run in report['runs']:
        definitions = {rule['id']: rule for rule in run['tool']['driver'].get('rules', [])}
        for finding in run['results']:
            rule = definitions.get(finding['ruleId'], {})
            severity = str(rule.get('properties', {}).get('security-severity', 'unspecified'))
            level = finding.get('level', rule.get('defaultConfiguration', {}).get('level', 'warning'))
            levels[level] += 1
            severities[severity] += 1
            rules[finding['ruleId']] += 1
            findings.append({
                'ruleId': finding['ruleId'], 'ruleName': rule.get('name'), 'level': level,
                'securitySeverity': severity, 'precision': rule.get('properties', {}).get('precision'),
                'message': finding.get('message', {}), 'locations': finding.get('locations', []),
                'suppressions': finding.get('suppressions', []),
                'partialFingerprints': finding.get('partialFingerprints', {}),
            })
    return {'findingCount': len(findings), 'byLevel': dict(levels), 'bySecuritySeverity': dict(severities),
            'byRule': dict(rules), 'findings': findings,
            'interpretation': 'Analyzer results, not independently validated vulnerabilities; --fail-none permits findings.'}



def keeper_excerpts(source):
    """Retain only numbered configuration/routing evidence, never the complete application source."""
    lines = source.decode().splitlines()

    def find(marker, start=0):
        hits = [index for index in range(start, len(lines)) if marker in lines[index]]
        if not hits:
            raise ValueError('Missing pinned keeper evidence marker: ' + marker)
        return hits[0]

    submit = find('submitIntent cfg conn client dryRun observeCost deadlines intent = do')
    routing = find('case intent of', submit)
    routed = find('valueResult <- intentValue', routing)
    preflight_call = find('preflight <- preflightV2OrderTransaction', routed)
    legacy_quote = find('intentValue :: Config -> EthClient -> ExecutionIntent')
    legacy_end = find('submitKeeperTransaction ::', legacy_quote)
    preflight = find('preflightV2OrderTransaction cfg client value callKind callData observePending =')
    initial_cap = find('Right estimatedGas ->', preflight)
    initial_end = find('else runPreflight fromAddr initialGas', initial_cap)
    retry = find('retryWithMoreGas fromAddr gasLimit =', initial_end)
    retry_end = find('Just nextGas -> runPreflight fromAddr nextGas', retry)
    cap = find('v2OrderGasLimitCap :: Integer', retry_end)
    bounded = find('min maximumGas (currentGas * 2)', cap)
    sections = [
        ('Single and batch route selection', routing, routed),
        ('Shared outcome-aware preflight call', preflight_call, preflight_call + 1),
        ('Initial gas cap enforcement', initial_cap, initial_end + 1),
        ('Retry uses the same cap', retry, retry_end + 1),
        ('Cap declaration and bounded escalation', cap, bounded + 1),
        ('Legacy fee quote: gas-cap evidence does not imply V3 consumer compatibility', legacy_quote, legacy_end),
    ]
    text = 'Numbered excerpts from the immutable keeper source identified in evidence.json.\n'
    for title, first, end in sections:
        text += '\n' + title + '\n'
        text += '\n'.join(f'{index + 1}: {lines[index]}' for index in range(first, end)) + '\n'
    return text.encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--source-sha', required=True)
    parser.add_argument('--ci-run', type=int, required=True)
    parser.add_argument('--deep-run', type=int, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repository', default='Plether-Fi/plether-core')
    args = parser.parse_args()
    if not SHA.fullmatch(args.source_sha) or not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', args.repository):
        parser.error('Use an immutable full source SHA and owner/repository identifier')
    if args.output.exists():
        parser.error('Use a new output directory; existing evidence is never overwritten')
    workspace = args.workspace.resolve()
    sys.path.insert(0, str(workspace / 'scripts'))
    from oracle_sync_evidence import sanitize_log
    helper_source = workspace / 'scripts/oracle_sync_evidence.py'
    expected_helper = subprocess.check_output(['git', 'show', args.source_sha + ':scripts/oracle_sync_evidence.py'], cwd=workspace)
    if helper_source.read_bytes() != expected_helper:
        parser.error('Shared evidence helper differs from the target source revision')
    source_tree = subprocess.check_output(
        ['git', 'show', '-s', '--format=%T', args.source_sha], cwd=workspace, text=True).strip()
    if not SHA.fullmatch(source_tree):
        parser.error('Target source commit is not available locally')
    args.output.mkdir(parents=True)
    errors, checked, logs, runs, artifact_records, static_results = [], {}, {}, {}, [], {}
    job_inventory, keeper_record, invariant_receipts, attempt_history = {}, {}, {}, {}

    def save(name, value):
        path = args.output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        data = value if isinstance(value, bytes) else (json.dumps(value, indent=2) + '\n').encode()
        path.write_bytes(data)
        return {'path': name, 'sha256': sha256(data)}

    def api(path, raw=False):
        result = subprocess.run(['gh', 'api', f'repos/{args.repository}/{path}'], capture_output=True)
        if result.returncode:
            raise ValueError(sanitize_log(result.stderr.decode(errors='replace')))
        return result.stdout if raw else json.loads(result.stdout)

    def pages(path, key):
        result, page = [], 1
        while True:
            separator = '&' if '?' in path else '?'
            batch = api(f'{path}{separator}per_page=100&page={page}')[key]
            result.extend(batch)
            if len(batch) < 100:
                return result
            page += 1

    try:
        for label, run_id, expected, expected_name in (
            ('ci', args.ci_run, CI_JOBS, 'CI'),
            ('deep', args.deep_run, DEEP_JOBS, 'Perps Deep Tests'),
        ):
            run = api(f'actions/runs/{run_id}')
            runs[label] = {'id': run_id, 'attempt': run['run_attempt'], 'headSha': run['head_sha'],
                           'status': run['status'], 'conclusion': run['conclusion'], 'event': run['event']}
            save(f'{label}/run.json', run)
            if run['name'] != expected_name or run['head_sha'] != args.source_sha:
                errors.append(f'{label}: workflow name or source revision differs')
            if run['status'] != 'completed' or run['conclusion'] != 'success':
                errors.append(f'{label}: workflow is not completed successfully')
            if run['event'] not in ('pull_request', 'push', 'workflow_dispatch'):
                errors.append(f'{label}: scheduled/unsupported event cannot prove required fixed seed')
            # A failed-job retry reruns only failed jobs and their dependants. Select the latest
            # actual execution of EACH required job; never substitute an older success for a
            # newer failure, and retain prior failed/cancelled executions as explicit history.
            all_jobs = pages(f'actions/runs/{run_id}/jobs?filter=all', 'jobs')
            save(f'{label}/jobs-all-attempts.json', all_jobs)
            jobs = select_latest_jobs(all_jobs, run_id, args.source_sha, run['run_attempt'])
            selected_ids = {job['id'] for job in jobs}
            origins = {job['id']: execution_origin(job, all_jobs) for job in jobs}
            origin_ids = {job['id'] for job in origins.values()}
            attempt_history[label] = [
                {'jobId': job['id'], 'jobName': job['name'], 'runAttempt': job.get('run_attempt'),
                 'headSha': job.get('head_sha'), 'status': job['status'], 'conclusion': job['conclusion'],
                 'startedAt': job['started_at'], 'completedAt': job['completed_at'],
                 'selectedForQualification': job['id'] in selected_ids,
                 'usedAsOriginalExecution': job['id'] in origin_ids}
                for job in all_jobs]
            for previous in all_jobs:
                if previous['id'] in selected_ids or previous['conclusion'] == 'success':
                    continue
                raw_history = api(f'actions/jobs/{previous["id"]}/logs', raw=True)
                history_record = save(f'{label}/attempt-history/{previous["id"]}.log',
                                      sanitize_log(raw_history.decode(errors='replace')).encode())
                history_record.update(jobId=previous['id'], jobName=previous['name'],
                                      runAttempt=previous['run_attempt'], conclusion=previous['conclusion'],
                                      selectedForQualification=False, downloadedSha256=sha256(raw_history))
                artifact_records.append(history_record)
            save(f'{label}/jobs.json', jobs)
            job_inventory[label] = {'requiredNames': sorted(expected), 'jobs': [
                {'id': job['id'], 'name': job['name'], 'status': job['status'], 'conclusion': job['conclusion'],
                 'runAttempt': job['run_attempt'], 'runId': job['run_id'], 'headSha': job['head_sha']}
                for job in jobs]} 
            for item in job_inventory[label]['jobs']:
                origin = origins[item['id']]
                item.update(executionJobId=origin['id'], executionRunAttempt=origin['run_attempt'],
                            executionReusedByGitHub=origin['id'] != item['id'])
            names = [job['name'] for job in jobs]
            if set(names) != expected or len(names) != len(expected):
                errors.append(f'{label}: missing, duplicate or unexpected jobs: {sorted(set(names) ^ expected)}')
            for job in jobs:
                name = job['name']
                steps = {step['name']: step for step in job.get('steps', [])}
                for required in REQUIRED_STEPS.get(name, []):
                    if steps.get(required, {}).get('conclusion') != 'success':
                        errors.append(f'{name}: required step did not succeed: {required}')
                if job['status'] != 'completed' or job['conclusion'] != 'success':
                    errors.append(f'{label}: required job did not succeed: {name}')
                    continue
                raw_log = api(f'actions/jobs/{job["id"]}/logs', raw=True)
                origin = origins[job['id']]
                if origin['id'] != job['id']:
                    original_log = api(f'actions/jobs/{origin["id"]}/logs', raw=True)
                    if original_log != raw_log:
                        errors.append(f'{name}: copied retry execution log differs from original attempt')
                log = sanitize_log(raw_log.decode(errors='replace'))
                path = f'{label}/logs/{job["id"]}.log'
                logs[name] = log
                log_record = save(path, log.encode())
                log_record.update(jobId=job['id'], jobName=name, runAttempt=job['run_attempt'],
                                  executionJobId=origin['id'], executionRunAttempt=origin['run_attempt'],
                                  executionReusedByGitHub=origin['id'] != job['id'],
                                  headSha=job['head_sha'], selectedForQualification=True,
                                  downloadedSha256=sha256(raw_log))
                artifact_records.append(log_record)
                if name == 'Perps deep (all shards)':
                    continue
                checkout = checkout_commit(log)
                commit = api(f'git/commits/{checkout}')
                if commit['tree']['sha'] != source_tree:
                    errors.append(f'{name}: tested merge tree differs from target source tree')
                checked[name] = {'testedCommit': checkout, 'testedTree': commit['tree']['sha'],
                                 'parents': [item['sha'] for item in commit['parents']],
                                 'jobId': job['id'], 'runAttempt': job['run_attempt'], 'headSha': job['head_sha'],
                                 'executionJobId': origin['id'], 'executionRunAttempt': origin['run_attempt'],
                                 'executionReusedByGitHub': origin['id'] != job['id'],
                                 'treeEqualsTarget': commit['tree']['sha'] == source_tree}
                if name.startswith('Perps deep shard') and 'Using fuzz seed 0xdeadbeef' not in log:
                    errors.append(f'{name}: fixed-seed selection is missing')
            tested_shas = {entry['testedCommit'] for name, entry in checked.items()
                           if name in expected and name != 'Perps deep (all shards)'}
            if not tested_shas or (label == 'ci' and len(tested_shas) != 1):
                errors.append(f'{label}: checkout commits are missing or inconsistent')
            if label == 'ci' and len(tested_shas) == 1:
                tested_sha = next(iter(tested_shas))
                required_artifacts = {f'coverage-{scope}-{tested_sha}': f'lcov-{scope}.info'
                                      for scope in ('core', 'perps', 'options')}
                required_artifacts.update({f'slither-{package}-{tested_sha}': f'results-{package}.sarif'
                                           for package in ('shared', 'spot', 'options', 'perps', 'perps-aa')})
                available = pages(f'actions/runs/{run_id}/artifacts', 'artifacts')
                save('ci/artifacts.json', available)
                for name, filename in required_artifacts.items():
                    candidates = [item for item in available if item['name'] == name]
                    if len(candidates) != 1 or candidates[0]['expired']:
                        errors.append(f'Missing, duplicate or expired CI artifact: {name}')
                        continue
                    item = candidates[0]
                    if item.get('workflow_run', {}).get('head_sha') not in (args.source_sha, tested_sha) or item.get('workflow_run', {}).get('id') != run_id:
                        errors.append(f'Artifact source revision or originating run differs: {name}')
                    if item['created_at'] < run['run_started_at']:
                        errors.append(f'Artifact predates the selected run attempt: {name}')
                    archive = api(f'actions/artifacts/{item["id"]}/zip', raw=True)
                    actual_digest = 'sha256:' + sha256(archive)
                    if item.get('digest') != actual_digest:
                        errors.append(f'Artifact archive digest is missing or differs: {name}')
                    with zipfile.ZipFile(io.BytesIO(archive)) as zipped:
                        members = [entry for entry in zipped.infolist() if not entry.is_dir()]
                        if len(members) != 1 or Path(members[0].filename).name != filename or members[0].file_size > 64 * 1024 * 1024:
                            raise ValueError(f'Unexpected archive contents: {name}')
                        content = zipped.read(members[0])
                    artifact = save('ci/reports/' + filename, content)
                    artifact.update(artifactId=item['id'], artifactName=name, archiveSha256=sha256(archive),
                                    createdAt=item['created_at'], apiDigest=item.get('digest'))
                    artifact_records.append(artifact)
                    if filename.endswith('.sarif'):
                        static_results[filename] = sarif_summary(content)
                    elif not content.strip() or b'SF:' not in content or b'end_of_record' not in content:
                        errors.append(f'Missing or malformed coverage records: {filename}')
        if '[PASS] test_AllReleaseContractsFitFullDeploymentLimits()' not in logs.get('build', ''):
            errors.append('Normal CI did not prove the full local deployment-size test ran')
        deep_logs = {name: log for name, log in logs.items() if name.startswith('Perps deep shard')}
        invariant_receipts = {}
        for name in INVARIANTS:
            pattern = r'\[PASS\]\s+' + name + r'\(\)\s+\(runs:\s*16,\s*calls:\s*8000,\s*reverts:\s*0\)'
            matches = {job: re.findall(pattern, log) for job, log in deep_logs.items()}
            matches = {job: values for job, values in matches.items() if values}
            if len(matches) != 1 or sum(map(len, matches.values())) != 1:
                errors.append(f'Exactly one deep 16-run/8000-call/0-revert receipt required: {name}')
            invariant_receipts[name] = {job: values for job, values in matches.items()}
        new_invariant_jobs = set(invariant_receipts[INVARIANTS[0]]) | set(invariant_receipts[INVARIANTS[1]])
        if len(new_invariant_jobs) != 1 or not any('OracleEthConservationInvariantTest' in deep_logs[job] for job in new_invariant_jobs):
            errors.append('New ETH invariant suite and both properties must appear in the same deep shard')
        keeper_path = 'deployments/releases/atomic-oracle-sync-candidate/keeper-evidence.json'
        keeper_config_data = subprocess.check_output(
            ['git', 'show', args.source_sha + ':' + keeper_path], cwd=workspace)
        keeper_config = json.loads(keeper_config_data)
        if not SHA.fullmatch(keeper_config['sourceCommit']):
            raise ValueError('Keeper configuration must pin a full immutable source SHA')
        endpoint = ('repos/' + keeper_config['repository'] + '/contents/' + keeper_config['sourcePath']
                    + '?ref=' + keeper_config['sourceCommit'])
        fetched = json.loads(subprocess.check_output(['gh', 'api', endpoint]))
        keeper_source = base64.b64decode(fetched['content'])
        git_blob_sha = hashlib.sha1(b'blob ' + str(len(keeper_source)).encode() + b'\0' + keeper_source).hexdigest()
        if git_blob_sha != fetched['sha']:
            errors.append('Keeper source blob integrity check failed')
        matches = re.findall(r'^' + re.escape(keeper_config['symbol']) + r'\s*=\s*([0-9_]+)\s*$',
                             keeper_source.decode(), re.M)
        cap = int(matches[0].replace('_', '')) if len(matches) == 1 else None
        if cap != 30_000_000 or cap != keeper_config['orderGasLimit'] or cap != keeper_config['batchGasLimit']:
            errors.append('Pinned keeper source does not prove both required gas caps')
        keeper_file = save('keeper/gas-cap-routing-excerpts.txt', keeper_excerpts(keeper_source))
        keeper_record = dict(keeper_config, sourceBlobSha=fetched['sha'], sourceFileSha256=sha256(keeper_source),
                             sourceEvidence=keeper_file, configurationPath=keeper_path,
                             coreSourceCommit=args.source_sha, configurationSha256=sha256(keeper_config_data), observedGasLimit=cap,
                             gasCapEvidenceOnly=True, v3ConsumerCompatibilityVerified=False,
                             limitation='Pinned keeper still uses generic getUpdateFee; this proves a source-supported cap, not a compatible V3 consumer release or live service configuration.')
        core_gas_settings = {}
        for source_path, symbol, expected in (
            ('packages/perps/src/OrderRouterExecutionSidecar.sol', 'POST_ENGINE_GAS_RESERVE', 1_000_000),
            ('packages/perps/src/OrderRouterExecutionSidecar.sol', 'EVALUATOR_RETURN_GAS_RESERVE', 250_000),
            ('packages/perps/src/router/OrderRouterBase.sol', 'minEngineGas', 600_000),
        ):
            source = subprocess.check_output(['git', 'show', args.source_sha + ':' + source_path], cwd=workspace)
            values = re.findall(r'\b' + symbol + r'\s*=\s*([0-9_]+)\s*;', source.decode())
            actual = int(values[0].replace('_', '')) if len(values) == 1 else None
            if actual != expected:
                errors.append('Core gas setting differs from preserved release default: ' + symbol)
            core_gas_settings[symbol] = {'sourceCommit': args.source_sha, 'sourcePath': source_path,
                                         'sourceFileSha256': sha256(source), 'value': actual}
        keeper_record['coreGasSettings'] = core_gas_settings
        save('keeper/evidence.json', keeper_record)
        save('static-analysis-summary.json', static_results)
        save('deep-invariant-receipts.json', invariant_receipts)
    except Exception as error:
        errors.append(sanitize_log(str(error)))
    summary = {
        'purpose': 'Immutable CI evidence collection only; this does not declare release qualification.',
        'sourceCommit': args.source_sha, 'sourceTree': source_tree,
        'runs': runs, 'requiredJobInventory': job_inventory, 'checkoutEvidence': checked,
        'jobAttemptHistory': attempt_history,
        'retainedEvidence': artifact_records, 'deepInvariantReceipts': invariant_receipts,
        'keeperEvidence': keeper_record,
        'staticAnalysisCounts': {name: {key: value for key, value in record.items() if key != 'findings'}
                                 for name, record in static_results.items()},
        'collectionErrors': errors,
        'remainingGates': ['final source fingerprint', 'baseline/candidate real-Pyth regression',
                           'complete V3 gas matrix', 'ABI and all29 local deployment-size export',
                           'static-analysis finding interpretation', 'immutable keeper cap provenance'],
        'deployedQualification': False,
        'collector': {'path': Path(__file__).name, 'sha256': sha256(Path(__file__).read_bytes()),
                      'sharedHelperPath': 'scripts/oracle_sync_evidence.py', 'sharedHelperSha256': sha256(expected_helper)},
    }
    save('ci-collection.json', summary)
    checksums = {str(path.relative_to(args.output)): sha256(path.read_bytes())
                 for path in sorted(args.output.rglob('*')) if path.is_file()}
    save('SHA256SUMS.json', checksums)
    print(json.dumps({'sourceCommit': args.source_sha, 'output': str(args.output), 'collectionErrors': errors}, indent=2))
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
