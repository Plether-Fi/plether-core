#!/usr/bin/env python3
"""Package verified qualification outputs; no builds, network, signing, or deployment."""
import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

root = Path.cwd().resolve()
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-revision', required=True)
args = parser.parse_args()
revision = args.source_revision
assert len(revision) == 40 and all(c in '0123456789abcdef' for c in revision)
short = revision[:8]
work = root / 'artifacts/oracle-sync' / short
sys.dont_write_bytecode = True
sys.path.insert(0, str(root / 'scripts'))
from oracle_sync_evidence import source_fingerprint, validate_scenario_records, sha256_file

assert not (work / 'bundle/qualification-invalid.json').exists(), 'Rejected artifact bundle cannot qualify'
build = json.loads((work / 'bundle/build.json').read_text())
fork = json.loads((work / 'fork/result.json').read_text())
ci = json.loads((work / 'ci-evidence/ci-collection.json').read_text())
assert build['sourceCommit'] == fork['candidateSourceCommit'] == ci['sourceCommit'] == revision
assert fork['passed'] is True and fork['releaseMatrixPassed'] is True
assert fork['candidateHasUncommittedChanges'] is False
assert fork['inputFingerprintSha256'] == fork['afterInputFingerprintSha256'] == build['sourceFingerprint']['sha256']
assert source_fingerprint(root, revision) == build['sourceFingerprint']
assert ci['collectionErrors'] == [], ci['collectionErrors']
ci_checksums = json.loads((work / 'ci-evidence/SHA256SUMS.json').read_text())
ci_files = {str(p.relative_to(work / 'ci-evidence')) for p in (work / 'ci-evidence').rglob('*') if p.is_file() and p.name != 'SHA256SUMS.json'}
assert set(ci_checksums) == ci_files
for name, checksum in ci_checksums.items():
    assert sha256_file(work / 'ci-evidence' / name) == checksum
collector_path = Path(__file__).with_name('collect-oracle-sync-ci.py')
assert sha256_file(collector_path) == ci['collector']['sha256']
assert sha256_file(root / ci['collector']['sharedHelperPath']) == ci['collector']['sharedHelperSha256']
assert all(run['status'] == 'completed' and run['conclusion'] == 'success' for run in ci['runs'].values())
assert all(check['treeEqualsTarget'] for check in ci['checkoutEvidence'].values())
assert len(ci['requiredJobInventory']['ci']['jobs']) == 15
assert len(ci['requiredJobInventory']['deep']['jobs']) == 5
assert len(ci['staticAnalysisCounts']) == 5
validate_scenario_records(fork['matrix']['scenarios'], fork['matrix']['manifest'])
sizes = build['deploymentSizeValidation']['deployments']
assert build['artifactIsolation'] == 'fresh temporary output and cache shared by build and local deployment-size test'
assert build['compilerInputs'] and build['compilerSources']
assert len(sizes) == 29
assert all(d['runtimeBytes'] <= 24576 and d['creationInputBytes'] <= 49152 for d in sizes.values())
assert subprocess.run(['git', 'diff', '--quiet', '6fb45aee5b8ab3a9eb9a57656899afbf2d3c0f82', revision,
                      '--', 'packages/*/src', 'integration/src', 'lib', 'deployments/releases/atomic-oracle-sync-candidate'], cwd=root).returncode == 0

for name, record in build['logs'].items():
    assert record['exitCode'] == 0 and sha256_file(work / 'bundle' / name) == record['sha256']
for name in ('baseline', 'candidate'):
    assert fork['results'][name]['passed'] and fork['results'][name]['exitCode'] == 0
    assert sha256_file(work / 'fork' / (name + '.log')) == fork['results'][name]['logSha256']
assert sha256_file(work / 'fork/scenarios.log') == fork['matrix']['logSha256']
for record in ci['retainedEvidence']:
    assert sha256_file(work / 'ci-evidence' / record['path']) == record['sha256']
spec = importlib.util.spec_from_file_location('release_export_validation', root / 'scripts/export-perps-release.py')
exporter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exporter)
inventory = exporter.consumer_inventory(root, json.loads((root / 'deployments/arbitrum-sepolia-perps.template.json').read_text()))
artifacts = {}
for name, record in build['contracts'].items():
    assert sha256_file(work / 'bundle/abi' / (name + '.json')) == record['abiSha256']
    assert sha256_file(work / 'bundle' / record['artifact']) == record['artifactSha256']
    source, contract = record['sourceArtifact'].rsplit(':', 1)
    identifier = Path(source).name + ':' + contract
    assert contract == name and inventory[identifier] == source
    artifacts[identifier] = exporter.read_artifact(work / 'bundle' / record['artifact'])
    assert json.loads((work / 'bundle/abi' / (name + '.json')).read_text()) == artifacts[identifier]['abi']
assert set(artifacts) == set(inventory)
assert exporter.validate_metadata_sources(root, revision, inventory, artifacts) == build['compilerSources']

stage = work / ('release-evidence-v3-' + short)
assert not stage.exists(), 'Choose a new evidence version instead of overwriting'
stage.mkdir()
for source, target in (('bundle', 'build'), ('fork', 'fork'), ('ci-evidence', 'ci')):
    shutil.copytree(work / source, stage / target)
shutil.copytree(root / 'test/fixtures/oracle-sync', stage / 'test/fixtures/oracle-sync')
diagnostic_dir = work / 'local-deep-retry'
diagnostic = json.loads((diagnostic_dir / 'metadata.json').read_text())
assert diagnostic['sourceRevision'] == revision
assert diagnostic['fullLocalShardQualified'] is False
assert diagnostic['status'] == 'intentionally_interrupted' and diagnostic['exitCode'] == 130
assert diagnostic['trackedSourceCleanBefore'] and diagnostic['trackedSourceCleanAfter']
assert sha256_file(diagnostic_dir / 'run.log') == diagnostic['sanitizedLogSha256']
shutil.copytree(diagnostic_dir, stage / 'diagnostics/local-shard-replay')
(stage / 'provenance').mkdir()
for helper in (Path(__file__).with_name('collect-oracle-sync-ci.py'), Path(__file__)):
    shutil.copyfile(helper, stage / 'provenance' / Path(helper).name)
shutil.copyfile(root / 'deployments/arbitrum-sepolia-perps.template.json', stage / 'provenance/manifest-template.json')
shutil.copyfile(root / 'foundry.toml', stage / 'provenance/foundry.toml')
shutil.copyfile(root / 'packages/perps/foundry.toml', stage / 'provenance/perps-foundry.toml')

static_counts = ci['staticAnalysisCounts']
static_count = sum(record['findingCount'] for record in static_counts.values())
optional_skips = {}
for log in (stage / 'ci').glob('*/logs/*.log'):
    skipped = sorted({line.split('[SKIP]', 1)[1].strip() for line in log.read_text().splitlines() if '[SKIP]' in line})
    if skipped:
        optional_skips[str(log.relative_to(stage))] = skipped
qualification = {
    'schemaVersion': 1,
    'sourceCommit': revision,
    'sourceTree': ci['sourceTree'],
    'sourceFingerprintSha256': build['sourceFingerprint']['sha256'],
    'orderInterfaceVersion': build['orderInterfaceVersion'],
    'localQualificationComplete': True,
    'deployedQualificationComplete': False,
    'phase': 'locally-qualified-no-deployment',
    'gates': {
        'normalCI': {'passed': True, 'runId': ci['runs']['ci']['id'], 'requiredJobs': 15},
        'deepPerps': {'passed': True, 'runId': ci['runs']['deep']['id'], 'shards': 4, 'runs': 16, 'depth': 500, 'seed': '0xdeadbeef', 'newInvariantParticipated': True},
        'baselineCandidateRegression': {'passed': True, 'baselineSourceCommit': fork['baselineSourceCommit'], 'identicalPrices': fork['results']['candidate']['prices']},
        'realPythMatrix': {'passed': True, 'scenarios': 7, 'skipped': 0, 'isolation': 'transaction', 'gasCap': 30000000},
        'runtimeAndFullCreationInputs': {'passed': True, 'deployments': len(sizes), 'runtimeLimitBytes': 24576, 'creationInputLimitBytes': 49152},
        'abiExport': {'passed': True, 'abiCount': len(build['contracts']), 'forgeVersion': build['forgeVersion']},
        'unchangedInputs': {'passed': True, 'fingerprint': build['sourceFingerprint']['sha256']},
    },
    'staticAnalysis': {
        'commandsPassed': True, 'findingCount': static_count, 'packages': static_counts,
        'independentFindingTriageComplete': False,
        'interpretation': 'These are raw Slither detector findings, not newly validated vulnerabilities or a zero-findings claim. This follow-up changes no analyzed production source or dependency relative to PR #103. Findings are retained with rules, locations and severity; --fail-none command success does not resolve them.'
    },
    'optionalUnrelatedSkips': optional_skips,
    'limitations': [
        'Authentic Pyth quotes are zero at every captured block. Nonzero Oracle fees and allocation refunds are covered by the independently modeled MockPyth invariant, not these authentic fork measurements.',
        'Each real-Pyth scenario uses a positive 1-gwei surplus to prove immediate or deferred RouterAdmin refunds. A zero Oracle allocation never counts as an exercised Oracle claim.',
        'Call gas excludes transaction intrinsic gas and Arbitrum data fees; historical zero-fee measurements do not establish nonzero Pyth-transfer gas costs.',
        'Pinned keeper source proves the 30,000,000 cap only. It still uses generic fee quoting; compatible V3 keeper/frontend releases and live configuration are outside this qualification.',
        'Static-analysis findings were preserved separately from successful commands; this follow-up is not an independent security audit.',
        'No deployment, signer, broadcast, activation, migration, active-record change, or merge of PR #103 occurred in this follow-up.',
        'Evidence publication follows the tested source commit. Qualification applies to this immutable source revision, not automatically to later source changes.'
    ],
    'additionalDiagnostic': {'path': 'diagnostics/local-shard-replay/metadata.json',
        'usedForQualification': False, 'status': diagnostic['status'],
        'note': 'Local fuzz/invariant phase passed 17 tests. Redundant ordinary-phase compilation was intentionally stopped only after the required full cloud shard passed; this is not counted as a full local shard pass.'},
    'ciAttemptHistory': ci['jobAttemptHistory'],
    'selectedCiJobs': ci['requiredJobInventory'],
    'retryInterpretation': 'The first cloud attempt of deep shard 1 reached its unchanged 30-minute timeout during ordinary-test compilation after 17 fuzz/invariant tests passed. Prior unsuccessful logs are retained. Only the latest execution of each required job may qualify; successful jobs from earlier attempts must have the same immutable source and checkout tree.',
    'historicalEvidencePreserved': {'sourceCommit': 'eea28a5c35b043f1d1ae91372bd384e84cb1c745', 'index': 'deployments/releases/atomic-oracle-sync-candidate/manifest.json'},
}
(stage / 'qualification.json').write_text(json.dumps(qualification, indent=2) + '\n')
(stage / 'README.md').write_text(
    '# V3 oracle synchronization qualification evidence\n\n'
    f'Qualified source: `{revision}`. Local qualification is complete; deployed qualification is false.\n\n'
    'Start with `qualification.json`; `build/build.json` binds all ABIs and local creation inputs; '
    '`fork/result.json` contains the original comparison and every required isolated scenario; '
    '`ci/ci-collection.json` binds CI, deep shards, coverage, static findings and keeper cap evidence. '
    'All retained files are covered by `SHA256SUMS`. Public fixture bytes and provenance are under `test/fixtures/oracle-sync`.\n\n'
    'The source was clean and unchanged during build/fork qualification. CI synthetic merge commits have '
    'the exact source Git tree; each actual checkout is retained. Read the limitations in `qualification.json`, '
    'especially authentic zero Pyth fees, raw analyzer findings and separate consumer compatibility.\n')

hashes = []
for path in sorted(stage.rglob('*')):
    if path.is_file():
        hashes.append(f'{sha256_file(path)}  {path.relative_to(stage)}\n')
(stage / 'SHA256SUMS').write_text(''.join(hashes))
assert source_fingerprint(root, revision) == build['sourceFingerprint']
release_dir = root / 'deployments/releases/oracle-sync-validation' / ('v3-' + short)
assert not release_dir.exists(), 'Release version already exists'
release_dir.mkdir()
archive_path = release_dir / ('oracle-sync-v3-' + short + '.tar.gz')
with archive_path.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for path in sorted(stage.rglob('*')):
                if not path.is_file():
                    continue
                info = archive.gettarinfo(str(path), arcname=str(Path(stage.name) / path.relative_to(stage)))
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                info.mode = 0o644
                with path.open('rb') as content:
                    archive.addfile(info, content)
archive_hash = sha256_file(archive_path)
gas_evidence = {'sourceCommit': revision, 'measurementNote': fork['measurementNote'],
                'refundCoverage': fork['matrix']['refundCoverage'],
                'keeperConfiguration': ci['keeperEvidence'], 'scenarios': fork['matrix']['scenarios']}
(release_dir / 'gas-evidence.json').write_text(json.dumps(gas_evidence, indent=2) + '\n')
summary = dict(qualification)
summary['gasEvidence'] = {'path': 'gas-evidence.json', 'sha256': sha256_file(release_dir / 'gas-evidence.json')}
summary['bundle'] = {'path': archive_path.name, 'sha256': archive_hash, 'bytes': archive_path.stat().st_size, 'files': len(hashes) + 1}
(release_dir / 'manifest.json').write_text(json.dumps(summary, indent=2) + '\n')
(release_dir / 'SHA256SUMS').write_text(f'{archive_hash}  {archive_path.name}\n{sha256_file(release_dir / "manifest.json")}  manifest.json\n{sha256_file(release_dir / "gas-evidence.json")}  gas-evidence.json\n')
index = {'schemaVersion': 1, 'candidate': 'core-oracle-synchronization-v3', 'currentEvidence': 'v3-' + short + '/manifest.json',
         'sourceCommit': revision, 'localQualificationComplete': True, 'deployedQualificationComplete': False,
         'activeDeploymentRecordChanged': False, 'historicalEvidence': ['../atomic-oracle-sync-candidate/manifest.json']}
(release_dir.parent / 'candidate-index.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'archive': str(archive_path), 'sha256': archive_hash, 'bytes': archive_path.stat().st_size,
                  'abis': len(build['contracts']), 'staticFindings': static_count, 'optionalSkips': optional_skips}, indent=2))
