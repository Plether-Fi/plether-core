# V3 oracle synchronization qualification evidence

Qualified source: `593230140be1aebfe6e227264ad5e50742121ea4`. Local qualification is complete; deployed qualification is false.

Start with `qualification.json`; `build/build.json` binds all ABIs and local creation inputs; `fork/result.json` contains the original comparison and every required isolated scenario; `ci/ci-collection.json` binds CI, deep shards, coverage, static findings and keeper cap evidence. All retained files are covered by `SHA256SUMS`. Public fixture bytes and provenance are under `test/fixtures/oracle-sync`.

The source was clean and unchanged during build/fork qualification. CI synthetic merge commits have the exact source Git tree; each actual checkout is retained. Read the limitations in `qualification.json`, especially authentic zero Pyth fees, raw analyzer findings and separate consumer compatibility.
